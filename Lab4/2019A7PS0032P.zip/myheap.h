void* myalloc(int size);

void myfree(void* ptr, int size);

