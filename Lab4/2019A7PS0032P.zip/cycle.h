#include "linkedlist.h"

int testCycle(struct linkedList* l); //returns 1 if true, 0 if false


/////  Dummy Implementation  /////////
// int testCycle(struct linkedList* l)
// {
//     return 1;
// }